﻿namespace SE_Project
{
    partial class Add_Members
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Members));
            label1 = new Label();
            txtPassword = new TextBox();
            txtUsername = new TextBox();
            txtemail = new TextBox();
            txtphonenumber = new TextBox();
            txtfullname = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtBatch = new TextBox();
            label7 = new Label();
            txtDiscipline = new TextBox();
            label8 = new Label();
            txtExperience = new TextBox();
            label9 = new Label();
            btnSignUp = new Button();
            button3 = new Button();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            label10 = new Label();
            comboBox1 = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Comic Sans MS", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(259, 20);
            label1.Name = "label1";
            label1.Size = new Size(262, 50);
            label1.TabIndex = 2;
            label1.Text = "Add Members";
            // 
            // txtPassword
            // 
            txtPassword.ForeColor = Color.Gray;
            txtPassword.Location = new Point(421, 407);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.PlaceholderText = "Enter Password";
            txtPassword.Size = new Size(315, 31);
            txtPassword.TabIndex = 14;
            // 
            // txtUsername
            // 
            txtUsername.ForeColor = Color.Gray;
            txtUsername.Location = new Point(421, 352);
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Enter Username";
            txtUsername.Size = new Size(315, 31);
            txtUsername.TabIndex = 12;
            // 
            // txtemail
            // 
            txtemail.ForeColor = Color.Gray;
            txtemail.Location = new Point(421, 287);
            txtemail.Name = "txtemail";
            txtemail.PlaceholderText = "Enter Email";
            txtemail.Size = new Size(315, 31);
            txtemail.TabIndex = 10;
            // 
            // txtphonenumber
            // 
            txtphonenumber.ForeColor = Color.Gray;
            txtphonenumber.Location = new Point(421, 223);
            txtphonenumber.Name = "txtphonenumber";
            txtphonenumber.PlaceholderText = "Enter Phone Number";
            txtphonenumber.Size = new Size(315, 31);
            txtphonenumber.TabIndex = 8;
            // 
            // txtfullname
            // 
            txtfullname.Cursor = Cursors.IBeam;
            txtfullname.ForeColor = Color.Gray;
            txtfullname.Location = new Point(421, 167);
            txtfullname.Name = "txtfullname";
            txtfullname.PlaceholderText = "Enter Name";
            txtfullname.Size = new Size(315, 31);
            txtfullname.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(125, 408);
            label6.Name = "label6";
            label6.Size = new Size(137, 30);
            label6.TabIndex = 16;
            label6.Text = "Password";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(125, 350);
            label5.Name = "label5";
            label5.Size = new Size(142, 30);
            label5.TabIndex = 15;
            label5.Text = "Username";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(125, 288);
            label4.Name = "label4";
            label4.Size = new Size(82, 30);
            label4.TabIndex = 13;
            label4.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(125, 224);
            label3.Name = "label3";
            label3.Size = new Size(201, 30);
            label3.TabIndex = 11;
            label3.Text = "Phone Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(125, 168);
            label2.Name = "label2";
            label2.Size = new Size(139, 30);
            label2.TabIndex = 9;
            label2.Text = "Full Name";
            // 
            // txtBatch
            // 
            txtBatch.ForeColor = Color.Gray;
            txtBatch.Location = new Point(421, 469);
            txtBatch.Name = "txtBatch";
            txtBatch.PasswordChar = '*';
            txtBatch.PlaceholderText = "Enter Batch";
            txtBatch.Size = new Size(315, 31);
            txtBatch.TabIndex = 17;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(125, 470);
            label7.Name = "label7";
            label7.Size = new Size(87, 30);
            label7.TabIndex = 18;
            label7.Text = "Batch";
            // 
            // txtDiscipline
            // 
            txtDiscipline.ForeColor = Color.Gray;
            txtDiscipline.Location = new Point(421, 528);
            txtDiscipline.Name = "txtDiscipline";
            txtDiscipline.PasswordChar = '*';
            txtDiscipline.PlaceholderText = "Enter Descipline";
            txtDiscipline.Size = new Size(315, 31);
            txtDiscipline.TabIndex = 19;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(125, 529);
            label8.Name = "label8";
            label8.Size = new Size(144, 30);
            label8.TabIndex = 20;
            label8.Text = "Descipline";
            // 
            // txtExperience
            // 
            txtExperience.ForeColor = Color.Gray;
            txtExperience.Location = new Point(421, 593);
            txtExperience.Name = "txtExperience";
            txtExperience.PasswordChar = '*';
            txtExperience.PlaceholderText = "Enter Experience";
            txtExperience.Size = new Size(315, 31);
            txtExperience.TabIndex = 21;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(125, 594);
            label9.Name = "label9";
            label9.Size = new Size(154, 30);
            label9.TabIndex = 22;
            label9.Text = "Experience";
            // 
            // btnSignUp
            // 
            btnSignUp.BackColor = Color.DarkCyan;
            btnSignUp.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSignUp.ForeColor = SystemColors.ButtonHighlight;
            btnSignUp.Location = new Point(540, 658);
            btnSignUp.Name = "btnSignUp";
            btnSignUp.Size = new Size(222, 53);
            btnSignUp.TabIndex = 23;
            btnSignUp.Text = "Add Member";
            btnSignUp.UseVisualStyleBackColor = false;
            btnSignUp.Click += btnSignUp_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkCyan;
            button3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button3.ForeColor = SystemColors.ButtonHighlight;
            button3.Location = new Point(870, 261);
            button3.Name = "button3";
            button3.Size = new Size(165, 47);
            button3.TabIndex = 25;
            button3.Text = "Upload Picture";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(870, 74);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(156, 162);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 24;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaptionText;
            button1.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Red;
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(54, 58);
            button1.TabIndex = 26;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Black;
            button2.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(36, 695);
            button2.Name = "button2";
            button2.Size = new Size(110, 46);
            button2.TabIndex = 27;
            button2.Text = "Back";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(125, 117);
            label10.Name = "label10";
            label10.Size = new Size(186, 30);
            label10.TabIndex = 28;
            label10.Text = "Society Name";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(421, 117);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(315, 33);
            comboBox1.TabIndex = 29;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // Add_Members
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.backgroundimage;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1182, 766);
            Controls.Add(comboBox1);
            Controls.Add(label10);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(button3);
            Controls.Add(pictureBox1);
            Controls.Add(btnSignUp);
            Controls.Add(txtExperience);
            Controls.Add(label9);
            Controls.Add(txtDiscipline);
            Controls.Add(label8);
            Controls.Add(txtBatch);
            Controls.Add(label7);
            Controls.Add(txtPassword);
            Controls.Add(txtUsername);
            Controls.Add(txtemail);
            Controls.Add(txtphonenumber);
            Controls.Add(txtfullname);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Add_Members";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Add_Members";
            Load += Add_Members_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtPassword;
        private TextBox txtUsername;
        private TextBox txtemail;
        private TextBox txtphonenumber;
        private TextBox txtfullname;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtBatch;
        private Label label7;
        private TextBox txtDiscipline;
        private Label label8;
        private TextBox txtExperience;
        private Label label9;
        private Button btnSignUp;
        private Button button3;
        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private Label label10;
        private ComboBox comboBox1;
    }
}